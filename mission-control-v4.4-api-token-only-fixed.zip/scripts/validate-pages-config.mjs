import { readFileSync } from 'node:fs';
import { validatePagesConfig } from './pages-config.mjs';

let config;
try {
  config = JSON.parse(readFileSync('wrangler.jsonc', 'utf8'));
} catch (error) {
  console.error(`Invalid wrangler.jsonc: ${error.message}`);
  process.exit(1);
}

const errors = validatePagesConfig(config);
if (errors.length) {
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('Pages configuration validated: account ID is supplied only through the environment.');
