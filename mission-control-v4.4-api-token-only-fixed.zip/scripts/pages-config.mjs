export function createPagesConfig({ projectName, databaseName, databaseId, compatibilityDate }) {
  return {
    $schema: './node_modules/wrangler/config-schema.json',
    name: projectName,
    pages_build_output_dir: './public',
    compatibility_date: compatibilityDate,
    send_metrics: false,
    d1_databases: [
      {
        binding: 'DB',
        database_name: databaseName,
        database_id: databaseId,
        migrations_dir: './migrations'
      }
    ]
  };
}

export function validatePagesConfig(config) {
  const errors = [];
  if (!config || typeof config !== 'object' || Array.isArray(config)) {
    return ['Configuration must be a JSON object.'];
  }
  if ('account_id' in config) {
    errors.push('Pages configuration must not contain account_id; use CLOUDFLARE_ACCOUNT_ID instead.');
  }
  if (config.pages_build_output_dir !== './public') {
    errors.push('pages_build_output_dir must be ./public.');
  }
  const db = Array.isArray(config.d1_databases)
    ? config.d1_databases.find((item) => item?.binding === 'DB')
    : null;
  if (!db?.database_id || !db?.database_name) {
    errors.push('D1 binding DB must include database_name and database_id.');
  }
  return errors;
}
