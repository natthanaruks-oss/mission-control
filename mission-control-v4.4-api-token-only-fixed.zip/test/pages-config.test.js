import test from 'node:test';
import assert from 'node:assert/strict';
import { createPagesConfig, validatePagesConfig } from '../scripts/pages-config.mjs';

test('Pages config omits account_id and keeps the D1 binding', () => {
  const config = createPagesConfig({
    projectName: 'mission-control',
    databaseName: 'mission-control-db',
    databaseId: '11111111-2222-3333-4444-555555555555',
    compatibilityDate: '2026-08-04'
  });

  assert.equal(Object.hasOwn(config, 'account_id'), false);
  assert.equal(config.pages_build_output_dir, './public');
  assert.equal(config.d1_databases[0].binding, 'DB');
  assert.deepEqual(validatePagesConfig(config), []);
});

test('Pages config validator rejects account_id', () => {
  const errors = validatePagesConfig({
    account_id: 'not-supported-in-pages-config',
    pages_build_output_dir: './public',
    d1_databases: [{ binding: 'DB', database_name: 'db', database_id: 'id' }]
  });
  assert.match(errors.join(' '), /must not contain account_id/u);
});
